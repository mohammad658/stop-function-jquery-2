$(".moshiur").click(function(){
 $(".lorem").slideDown(2000);
});
 $(".btn").click(function(){
     $(".lorem").stop();
 });

